# Atomist 'scala-editors'

[![Slack Status](https://join.atomist.com/badge.svg)](https://join.atomist.com/)
