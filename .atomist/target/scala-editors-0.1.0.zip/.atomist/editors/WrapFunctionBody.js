var WrapFunctionBody = (function () {
    function WrapFunctionBody() {
        this.name = "WrapFunctionBody";
        this.description = "just put positionedStructure() around my parsers";
    }
    WrapFunctionBody.prototype.edit = function (project) {
        var eng = project.context().pathExpressionEngine();
        var targets = "//File()[@name=\"ElmParser.scala\"]/ScalaFile()//defnDef[/typeApply[@value=\"Parser[SyntaxNode]\"]]";
        eng.with(project, targets, function (defStatement) {
            console.log(defStatement.value());
            defStatement.typeApply().update("Parser[PositionedSyntaxNode]");
            defStatement.termApplyInfix().update("positionedNode(" + defStatement.termApplyInfix().value() + ")");
            console.log("something: " + defStatement.termApplyInfix().value());
        });
    };
    return WrapFunctionBody;
}());
exports.editor = new WrapFunctionBody();
//# sourceMappingURL=WrapFunctionBody.js.map