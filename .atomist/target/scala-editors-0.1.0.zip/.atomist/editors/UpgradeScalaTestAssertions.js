var UpgradeScalaTestAssertions = (function () {
    function UpgradeScalaTestAssertions() {
        this.name = "UpgradeScalaTestAssertions";
        this.description = "Upgrades ScalaTest assertions";
    }
    UpgradeScalaTestAssertions.prototype.edit = function (project) {
        var eng = project.context().pathExpressionEngine();
        var oldAssertion = "/src/test/scala//ScalaFile()//termApplyInfix[/termName[@value='should']][termSelect]";
        eng.with(project, oldAssertion, function (shouldTerm) {
            var termSelect = shouldTerm.termSelect();
            var termApply = shouldTerm.termApply();
            if (termApply != null && ["be", "equal"].indexOf(termApply.termName().value()) > -1
                && ["empty", "defined"].indexOf(termApply.children()[1].value()) < 0) {
                var newValue = "assert(" + termSelect.value() + " === " + termApply.children()[1].value() + ")";
                console.log("Replacing [" + shouldTerm.value() + "] with [" + newValue + "]");
                shouldTerm.update(newValue);
            }
        });
    };
    return UpgradeScalaTestAssertions;
}());
exports.editor = new UpgradeScalaTestAssertions();
//# sourceMappingURL=UpgradeScalaTestAssertions.js.map