var RugOperation_1 = require("@atomist/rug/operations/RugOperation");
exports.upgradeScalaTestAssertions = {
    description: "Upgrades ScalaTest assertions",
    name: "UpgradeScalaTestAssertions",
    parameters: [],
    execute: function (services, p) {
        for (var _i = 0, _a = services.services(); _i < _a.length; _i++) {
            var s = _a[_i];
            s.editWith("UpgradeScalaTestAssertions", {});
        }
        return new RugOperation_1.Result(RugOperation_1.Status.Success, "OK");
    }
};
//# sourceMappingURL=UpgradeScalaTestAssertions.js.map